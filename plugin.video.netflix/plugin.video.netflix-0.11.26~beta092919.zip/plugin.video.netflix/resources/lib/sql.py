#!/usr/bin/env python
# -*- coding: utf-8 -*-
from common import xbmc, addon, xbmcvfs, xbmcgui, os, Dialog, Log, getString, getConfig, writeConfig, homepath, pluginname
from BeautifulSoup import BeautifulSoup

def connSQL(dbname):
    cnx = None
    import mysql.connector
    from mysql.connector import errorcode
    dbname = 'netflix_' + dbname
    mysql_config = {
        'host': addon.getSetting('dbhost'),
        'port': addon.getSetting('dbport'),
        'user': addon.getSetting('dbuser'),
        'password': addon.getSetting('dbpass'),
        'database': dbname,
        'use_unicode': False,
        'get_warnings': True,
        'buffered': True
    try:
        cnx = mysql.connector.connect(**mysql_config)
    except mysql.connector.Error as err:
        if err.errno == errorcode.CR_CONN_HOST_ERROR:
            Dialog.notification('MySQL/MariaDB', getString(30224), xbmcgui.NOTIFICATION_ERROR)
        elif err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            Dialog.notification('MySQL/MariaDB', getString(30225), xbmcgui.NOTIFICATION_ERROR)
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            mysql_config['database'] = None
            cnx = mysql.connector.connect(**mysql_config)
            c = cnx.cursor()
            cur_exec(c, 'CREATE DATABASE %s CHARACTER SET utf8 COLLATE utf8_general_ci;' % dbname)
            cnx.database = dbname
            createDatabase(cnx, dbname)
        else:
            Log(err)

    if not cnx:
        exit()
    return cnx


def loadSQLconfig():
    keys = 'host port user pass'
    userdata = xbmc.translatePath('special://userdata').decode('utf-8')
    asfile = os.path.join(userdata, 'advancedsettings.xml')
    if xbmcvfs.exists(asfile):
        f = xbmcvfs.File(asfile, 'r')
        soup = BeautifulSoup(f.read(), convertEntities=BeautifulSoup.XML_ENTITIES)
        videodb = soup.advancedsettings.videodatabase
        if videodb:
            for tag in videodb.findAll():
                if tag.name in keys:
                    addon.setSetting('db'+tag.name, tag.string)
        else:
            Dialog.notification(pluginname, getString(30226))
    else:
        Dialog.notification(pluginname, getString(30226))


def createDatabase(cnx, dbname):
    c = cnx.cursor()
    if 'meta' in dbname:
        cur_exec(c, 'drop table if exists meta')
        cur_exec(c, '''create table meta(
                     videoid VARCHAR(144) UNIQUE,
                     title TEXT,
                     poster TEXT,
                     plot TEXT,
                     fanart TEXT,
                     PRIMARY KEY(videoid))''')
    cnx.commit()
    c.close()
