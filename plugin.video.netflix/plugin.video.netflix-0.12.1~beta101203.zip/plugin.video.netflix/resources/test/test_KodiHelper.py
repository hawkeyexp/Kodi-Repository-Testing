# -*- coding: utf-8 -*-
# Module: KodiHelper
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `KodiHelper` module"""

import unittest
import mock
from resources.lib.KodiHelper import KodiHelper

class KodiHelperTestCase(unittest.TestCase):
    pass
