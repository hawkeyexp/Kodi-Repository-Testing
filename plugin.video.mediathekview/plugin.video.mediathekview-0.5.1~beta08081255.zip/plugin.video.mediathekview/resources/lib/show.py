# -*- coding: utf-8 -*-
# Copyright 2017 Leo Moll and Dominik Schlösser
#

# -- Imports ------------------------------------------------

# -- Classes ------------------------------------------------
class Show( object ):
	def __init__( self ):
		self.id			= 0
		self.channelid	= 0
		self.show		= ''
		self.channel	= ''