# -*- coding: utf-8 -*-
# Copyright 2017 Leo Moll and Dominik Schlösser
#

# -- Imports ------------------------------------------------

# -- Classes ------------------------------------------------
class Channel( object ):
	def __init__( self ):
		self.id			= 0
		self.channel	= ''