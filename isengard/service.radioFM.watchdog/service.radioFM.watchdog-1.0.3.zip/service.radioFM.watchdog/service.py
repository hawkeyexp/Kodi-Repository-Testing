import xbmc
import xbmcgui
import xbmcaddon
import socket
import time

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")
autoresumeradio = addon.getSetting('AutoResumeRadio')
active = 0

# Open socket for communication with the gpio-manager UDP server
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def CarpcController_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Send request to server
        sock.sendto(command + "\0", (UDP_IP, UDP_PORT))

while True and (not xbmc.abortRequested):
    if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "true" and str(xbmc.getCondVisibility('Player.HasMedia')) == "1" and active == 0:
    	CarpcController_SendCommand("system_mode_toggle")
	active = 1

    if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false" and str(xbmc.getCondVisibility('Player.HasMedia')) == "0" and str(autoresumeradio) == "true" and active == 1:
    	CarpcController_SendCommand("system_mode_toggle")
	active = 0

    # give us a break
    time.sleep(1.0)
