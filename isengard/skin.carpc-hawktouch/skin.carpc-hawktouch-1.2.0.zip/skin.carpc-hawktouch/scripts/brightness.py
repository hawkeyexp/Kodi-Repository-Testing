import os

os.system("sudo cat /sys/class/backlight/rpi_backlight/brightness > /tmp/brightness.txt")

with open('/tmp/brightness.txt') as f:
	for i in xrange(1):
		value = f.readline().rstrip()

		if int(value) == 255:
			os.system("echo 25 | sudo tee /sys/class/backlight/rpi_backlight/brightness")
		else:
			os.system("echo 255 | sudo tee /sys/class/backlight/rpi_backlight/brightness")
